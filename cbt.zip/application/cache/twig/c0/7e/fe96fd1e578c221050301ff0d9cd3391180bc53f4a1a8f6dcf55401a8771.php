<?php

/* tambah-tugas.html */
class __TwigTemplate_c07efe96fd1e578c221050301ff0d9cd3391180bc53f4a1a8f6dcf55401a8771 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = $this->env->loadTemplate("layout-private.html");

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout-private.html";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        // line 4
        echo "Tambah Tugas ";
        echo twig_escape_filter($this->env, (isset($context["type_label"]) ? $context["type_label"] : null), "html", null, true);
        echo " - ";
        $this->displayParentBlock("title", $context, $blocks);
        echo "
";
    }

    // line 7
    public function block_content($context, array $blocks = array())
    {
        // line 8
        echo "<div class=\"module\">
    <div class=\"module-head\">
        <h3>";
        // line 10
        echo anchor("tugas", "Tugas");
        echo " / Tambah Tugas ";
        echo twig_escape_filter($this->env, (isset($context["type_label"]) ? $context["type_label"] : null), "html", null, true);
        echo "</h3>
    </div>
    <div class=\"module-body\">
        ";
        // line 13
        echo get_flashdata("tugas");
        echo "

        ";
        // line 15
        echo form_open_multipart(("plugins/custom_tugas/add/" . (isset($context["type"]) ? $context["type"] : null)), array("class" => "form-horizontal row-fluid"));
        echo "
            <div class=\"control-group\">
                <label class=\"control-label\">Judul <span class=\"text-error\">*</span></label>
                <div class=\"controls\">
                    <input type=\"text\" name=\"judul\"  class=\"span12\" value=\"";
        // line 19
        echo twig_escape_filter($this->env, set_value("judul"), "html", null, true);
        echo "\">
                    <br>";
        // line 20
        echo form_error("judul");
        echo " 
\t\t\t\t\t<i> contoh : PAT-Bahasa Inggris-10ipa </i>
                </div>
            </div>
            <div class=\"control-group\">
                <label class=\"control-label\">Matapelajaran <span class=\"text-error\">*</span></label>
                <div class=\"controls\">
                    <select name=\"mapel_id\">
                        <option value=\"\">--pilih--</option>
                        ";
        // line 29
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["mapel"]) ? $context["mapel"] : null));
        foreach ($context['_seq'] as $context["_key"] => $context["m"]) {
            // line 30
            echo "                        <option value=\"";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["m"]) ? $context["m"] : null), "id"), "html", null, true);
            echo "\" ";
            echo twig_escape_filter($this->env, set_select("mapel_id", $this->getAttribute((isset($context["m"]) ? $context["m"] : null), "id")), "html", null, true);
            echo ">";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["m"]) ? $context["m"] : null), "nama"), "html", null, true);
            echo "</option>
                        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['m'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 32
        echo "                    </select>
                    <br>";
        // line 33
        echo form_error("mapel_id");
        echo "
                </div>
            </div>
            <div class=\"control-group\">
                <label class=\"control-label\">Kelas <span class=\"text-error\">*</span></label>
                <div class=\"controls\">
                    <ul class=\"unstyled inline\" style=\"margin-left: -5px;\">
                        ";
        // line 40
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["kelas"]) ? $context["kelas"] : null));
        foreach ($context['_seq'] as $context["_key"] => $context["k"]) {
            // line 41
            echo "                        <li>
                            <label class=\"checkbox inline\">
                                <input type=\"checkbox\" name=\"kelas_id[]\" value=\"";
            // line 43
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["k"]) ? $context["k"] : null), "id"), "html", null, true);
            echo "\" ";
            echo twig_escape_filter($this->env, set_checkbox("kelas_id[]", $this->getAttribute((isset($context["k"]) ? $context["k"] : null), "id")), "html", null, true);
            echo "> ";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["k"]) ? $context["k"] : null), "nama"), "html", null, true);
            echo "
                            </label>
                        </li>
                        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['k'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 47
        echo "                    </ul>
                    ";
        // line 48
        echo form_error("kelas_id[]");
        echo "
                </div>
            </div>
            <div class=\"control-group\">
                <label class=\"control-label\">Info</label>
                <div class=\"controls\">
                    <textarea name=\"info\" id=\"info\" class=\"texteditor\">";
        // line 54
        echo set_value("info");
        echo "</textarea>
                    ";
        // line 55
        echo form_error("info");
        echo "
                </div>
            </div>
            ";
        // line 58
        if (((isset($context["type"]) ? $context["type"] : null) != 1)) {
            // line 59
            echo "            <div class=\"control-group\">
                <label class=\"control-label\">Maksimal jumlah soal</label>
                <div class=\"controls\">
                    <input type=\"text\" name=\"max_jml_soal\" class=\"span2\" value=\"";
            // line 62
            echo twig_escape_filter($this->env, set_value("max_jml_soal"), "html", null, true);
            echo "\">
                    <br><span class=\"text-warning\">*) jika maksimal jumlah soal diatur 10 dan soal diinputkan 20, maka hanya akan diambil 10 dari 20 soal</span>
                    <br>";
            // line 64
            echo form_error("max_jml_soal");
            echo "
                </div>
            </div>
            <div class=\"control-group\">
                <label class=\"control-label\">Model urutan soal</label>
                <div class=\"controls\">
                    <label class=\"radio inline\"><input type=\"radio\" name=\"model_urutan_soal\" value=\"1\" ";
            // line 70
            echo twig_escape_filter($this->env, set_radio("model_urutan_soal", "1", true), "html", null, true);
            echo "> Acak</label>
                    <label class=\"radio inline\"><input type=\"radio\" name=\"model_urutan_soal\" value=\"2\" ";
            // line 71
            echo twig_escape_filter($this->env, set_radio("model_urutan_soal", "2"), "html", null, true);
            echo "> Berurutan</label>
                    <br>";
            // line 72
            echo form_error("model_urutan_soal");
            echo "
                </div>
            </div>
            ";
            // line 75
            if (((isset($context["type"]) ? $context["type"] : null) == 3)) {
                // line 76
                echo "            <div class=\"control-group\">
                <label class=\"control-label\">Model urutan pilihan</label>
                <div class=\"controls\">
                    <label class=\"radio inline\"><input type=\"radio\" name=\"model_urutan_pilihan\" value=\"1\" ";
                // line 79
                echo twig_escape_filter($this->env, set_radio("model_urutan_pilihan", "1"), "html", null, true);
                echo "> Acak</label>
                    <label class=\"radio inline\"><input type=\"radio\" name=\"model_urutan_pilihan\" value=\"2\" ";
                // line 80
                echo twig_escape_filter($this->env, set_radio("model_urutan_pilihan", "2", true), "html", null, true);
                echo "> Berurutan</label>
                    <br>";
                // line 81
                echo form_error("model_urutan_pilihan");
                echo "
                </div>
            </div>
            ";
            }
            // line 85
            echo "            <div class=\"control-group\">
                <label class=\"control-label\">Tampil soal perhalaman</label>
                <div class=\"controls\">
                    <label class=\"radio inline\"><input type=\"radio\" name=\"tampil_soal_perhalaman\" value=\"0\" ";
            // line 88
            echo twig_escape_filter($this->env, set_radio("tampil_soal_perhalaman", "0", true), "html", null, true);
            echo "> Semua</label>
                    <label class=\"radio inline\"><input type=\"radio\" name=\"tampil_soal_perhalaman\" value=\"1\" ";
            // line 89
            echo twig_escape_filter($this->env, set_radio("tampil_soal_perhalaman", "1"), "html", null, true);
            echo "> 1</label>
                    <label class=\"radio inline\"><input type=\"radio\" name=\"tampil_soal_perhalaman\" value=\"5\" ";
            // line 90
            echo twig_escape_filter($this->env, set_radio("tampil_soal_perhalaman", "5"), "html", null, true);
            echo "> 5</label>
                    <label class=\"radio inline\"><input type=\"radio\" name=\"tampil_soal_perhalaman\" value=\"10\" ";
            // line 91
            echo twig_escape_filter($this->env, set_radio("tampil_soal_perhalaman", "10"), "html", null, true);
            echo "> 10</label>
                    <br>";
            // line 92
            echo form_error("tampil_soal_perhalaman");
            echo "
                </div>
            </div>
            <div class=\"control-group\">
                <label class=\"control-label\">Durasi <span class=\"text-error\">*</span></label>
                <div class=\"controls\">
                    <input type=\"text\" name=\"durasi\" class=\"span2\" value=\"";
            // line 98
            echo twig_escape_filter($this->env, set_value("durasi"), "html", null, true);
            echo "\" placeholder=\"Dalam menit\">
                    <br>";
            // line 99
            echo form_error("durasi");
            echo "
                </div>
            </div>
            ";
        }
        // line 103
        echo "            <div class=\"control-group\">
                <label class=\"control-label\">Tampil nilai ke siswa</label>
                <div class=\"controls\">
                    ";
        // line 106
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable(plugin_helper("custom_tugas", "ct_option_tampil_nilai_kesiswa"));
        $context['loop'] = array(
          'parent' => $context['_parent'],
          'index0' => 0,
          'index'  => 1,
          'first'  => true,
        );
        if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof Countable)) {
            $length = count($context['_seq']);
            $context['loop']['revindex0'] = $length - 1;
            $context['loop']['revindex'] = $length;
            $context['loop']['length'] = $length;
            $context['loop']['last'] = 1 === $length;
        }
        foreach ($context['_seq'] as $context["key"] => $context["label"]) {
            // line 107
            echo "                        <label class=\"radio\"><input type=\"radio\" name=\"tampil_nilai_kesiswa\" value=\"";
            echo twig_escape_filter($this->env, (isset($context["key"]) ? $context["key"] : null), "html", null, true);
            echo "\" ";
            echo twig_escape_filter($this->env, set_radio("tampil_nilai_kesiswa", (isset($context["key"]) ? $context["key"] : null), ((($this->getAttribute((isset($context["loop"]) ? $context["loop"] : null), "index") == 1)) ? (true) : (""))), "html", null, true);
            echo "> ";
            echo twig_escape_filter($this->env, (isset($context["label"]) ? $context["label"] : null), "html", null, true);
            echo "</label>
                    ";
            ++$context['loop']['index0'];
            ++$context['loop']['index'];
            $context['loop']['first'] = false;
            if (isset($context['loop']['length'])) {
                --$context['loop']['revindex0'];
                --$context['loop']['revindex'];
                $context['loop']['last'] = 0 === $context['loop']['revindex0'];
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['key'], $context['label'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 109
        echo "                    ";
        echo form_error("tampil_nilai_kesiswa");
        echo "
                </div>
            </div>
            <div class=\"control-group\">
                <label class=\"control-label\">Terbitkan pada</label>
                <div class=\"controls\">
                    <input type=\"text\" name=\"terbitkan_pada\" id=\"terbitkan_pada\" class=\"span3\" value=\"";
        // line 115
        echo twig_escape_filter($this->env, set_value("terbitkan_pada"), "html", null, true);
        echo "\"> <br>Format: Tahun-Bulan-Tanggal Jam:Menit. Contoh: 2017-08-22 21:30
                    <br>";
        // line 116
        echo form_error("terbitkan_pada");
        echo "
                </div>
            </div>
            <div class=\"control-group\">
                <label class=\"control-label\">Tutup pada</label>
                <div class=\"controls\">
                    <input type=\"text\" name=\"tutup_pada\" id=\"tutup_pada\" class=\"span3\" value=\"";
        // line 122
        echo twig_escape_filter($this->env, set_value("tutup_pada"), "html", null, true);
        echo "\"> <br>Format: Tahun-Bulan-Tanggal Jam:Menit. Contoh: 2017-08-24 08:00
                    <br>";
        // line 123
        echo form_error("tutup_pada");
        echo "
                </div>
            </div>
            <div class=\"control-group\">
                <div class=\"controls\">
                    <button type=\"submit\" class=\"btn btn-primary\">Simpan</button>
                    <a href=\"";
        // line 129
        echo twig_escape_filter($this->env, site_url("tugas"), "html", null, true);
        echo "\" class=\"btn btn-default\">Kembali</a>
                </div>
            </div>
        ";
        // line 132
        echo form_close();
        echo "

    </div>
</div>
";
    }

    public function getTemplateName()
    {
        return "tambah-tugas.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  341 => 132,  335 => 129,  326 => 123,  322 => 122,  313 => 116,  309 => 115,  299 => 109,  278 => 107,  261 => 106,  256 => 103,  249 => 99,  245 => 98,  236 => 92,  232 => 91,  228 => 90,  224 => 89,  220 => 88,  215 => 85,  208 => 81,  204 => 80,  200 => 79,  195 => 76,  193 => 75,  187 => 72,  183 => 71,  179 => 70,  170 => 64,  165 => 62,  160 => 59,  158 => 58,  152 => 55,  148 => 54,  139 => 48,  136 => 47,  122 => 43,  118 => 41,  114 => 40,  104 => 33,  101 => 32,  88 => 30,  84 => 29,  72 => 20,  68 => 19,  61 => 15,  56 => 13,  48 => 10,  44 => 8,  41 => 7,  32 => 4,  29 => 3,);
    }
}
