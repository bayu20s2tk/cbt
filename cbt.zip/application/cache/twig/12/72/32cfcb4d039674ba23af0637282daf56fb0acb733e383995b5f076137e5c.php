<?php

/* info-tugas.html */
class __TwigTemplate_127232cfcb4d039674ba23af0637282daf56fb0acb733e383995b5f076137e5c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<b><a class=\"as-link\" data-toggle=\"collapse\" data-target=\"#detail-tugas\"><i class=\"icon-info-sign\" style=\"line-height: 0px;\"></i> ";
        echo twig_escape_filter($this->env, twig_upper_filter($this->env, $this->getAttribute((isset($context["tugas"]) ? $context["tugas"] : null), "judul")), "html", null, true);
        echo "</a></b>

<div id=\"detail-tugas\" class=\"collapse\" style=\"margin-top: 5px;\">
    <table class=\"table\">
        <tr>
            <th style=\"border-top: none;\" width=\"30%\">Tipe</th>
            <td style=\"border-top: none;\">";
        // line 7
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["tugas"]) ? $context["tugas"] : null), "type_label"), "html", null, true);
        echo "</td>
        </tr>
        <tr>
            <th>Judul</th>
            <td>";
        // line 11
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["tugas"]) ? $context["tugas"] : null), "judul"), "html", null, true);
        echo "</td>
        </tr>
        <tr>
            <th>Matapelajaran</th>
            <td>";
        // line 15
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["tugas"]) ? $context["tugas"] : null), "mapel"), "nama"), "html", null, true);
        echo "</td>
        </tr>
        <tr>
            <th>Kelas</th>
            <td>
                <ul class=\"unstyled inline\" style=\"margin-left: -5px;margin-bottom: 0px;\">
                    ";
        // line 21
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable($this->getAttribute((isset($context["tugas"]) ? $context["tugas"] : null), "tugas_kelas"));
        foreach ($context['_seq'] as $context["_key"] => $context["k"]) {
            // line 22
            echo "                    <li>";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["k"]) ? $context["k"] : null), "nama"), "html", null, true);
            echo "</li>
                    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['k'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 24
        echo "                </ul>
            </td>
        </tr>
        <tr>
            <th>Info</th>
            <td>";
        // line 29
        echo $this->getAttribute((isset($context["tugas"]) ? $context["tugas"] : null), "info");
        echo "</td>
        </tr>
        ";
        // line 31
        if (($this->getAttribute((isset($context["tugas"]) ? $context["tugas"] : null), "type_id") != 1)) {
            // line 32
            echo "        ";
            $context["pengaturan_tugas"] = plugin_helper("custom_tugas", "get_pengaturan_tugas", array("tugas_id" => $this->getAttribute((isset($context["tugas"]) ? $context["tugas"] : null), "id")));
            // line 33
            echo "        <tr>
            <th>Maksimal jumlah soal</th>
            <td>";
            // line 35
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["pengaturan_tugas"]) ? $context["pengaturan_tugas"] : null), "max_jml_soal"), "html", null, true);
            echo "</td>
        </tr>
        <tr>
            <th>Model urutan soal</th>
            <td>";
            // line 39
            echo ((($this->getAttribute((isset($context["pengaturan_tugas"]) ? $context["pengaturan_tugas"] : null), "model_urutan_soal") == 1)) ? ("Acak") : ("Berurutan"));
            echo "</td>
        </tr>
        ";
            // line 41
            if (($this->getAttribute((isset($context["tugas"]) ? $context["tugas"] : null), "type_id") == 3)) {
                // line 42
                echo "        <tr>
            <th>Model urutan pilihan</th>
            <td>";
                // line 44
                echo ((($this->getAttribute((isset($context["pengaturan_tugas"]) ? $context["pengaturan_tugas"] : null), "model_urutan_pilihan") == 1)) ? ("Acak") : ("Berurutan"));
                echo "</td>
        </tr>
        ";
            }
            // line 47
            echo "        <tr>
            <th>Tampil soal perhalaman</th>
            <td>";
            // line 49
            echo twig_escape_filter($this->env, ((($this->getAttribute((isset($context["pengaturan_tugas"]) ? $context["pengaturan_tugas"] : null), "tampil_soal_perhalaman") == 0)) ? ("Semua") : ($this->getAttribute((isset($context["pengaturan_tugas"]) ? $context["pengaturan_tugas"] : null), "tampil_soal_perhalaman"))), "html", null, true);
            echo "</td>
        </tr>
        <tr>
            <th>Durasi</th>
            <td>";
            // line 53
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["tugas"]) ? $context["tugas"] : null), "durasi"), "html", null, true);
            echo " Menit</td>
        </tr>
        ";
        }
        // line 56
        echo "        <tr>
            <th>Tampil nilai ke siswa</th>
            <td>
                ";
        // line 59
        if (twig_test_empty($this->getAttribute((isset($context["pengaturan_tugas"]) ? $context["pengaturan_tugas"] : null), "tampil_nilai_kesiswa"))) {
            // line 60
            echo "                    ";
            $context["option_tampil_nilai_kesiswa"] = 1;
            // line 61
            echo "                ";
        } else {
            // line 62
            echo "                    ";
            $context["option_tampil_nilai_kesiswa"] = $this->getAttribute((isset($context["pengaturan_tugas"]) ? $context["pengaturan_tugas"] : null), "tampil_nilai_kesiswa");
            // line 63
            echo "                ";
        }
        // line 64
        echo "
                ";
        // line 65
        echo twig_escape_filter($this->env, plugin_helper("custom_tugas", "ct_option_tampil_nilai_kesiswa", array(0 => (isset($context["option_tampil_nilai_kesiswa"]) ? $context["option_tampil_nilai_kesiswa"] : null))), "html", null, true);
        echo "
            </td>
        </tr>
        <tr>
            <th>Otomatis terbit pada</th>
            <td>";
        // line 70
        echo twig_escape_filter($this->env, tgl_jam_indo($this->getAttribute((isset($context["pengaturan_tugas"]) ? $context["pengaturan_tugas"] : null), "terbitkan_pada")), "html", null, true);
        echo "</td>
        </tr>
        <tr>
            <th>Otomatis tutup pada</th>
            <td>";
        // line 74
        echo twig_escape_filter($this->env, tgl_jam_indo($this->getAttribute((isset($context["pengaturan_tugas"]) ? $context["pengaturan_tugas"] : null), "tutup_pada")), "html", null, true);
        echo "</td>
        </tr>
    </table>
</div>
";
    }

    public function getTemplateName()
    {
        return "info-tugas.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  164 => 74,  157 => 70,  149 => 65,  146 => 64,  143 => 63,  140 => 62,  137 => 61,  134 => 60,  132 => 59,  127 => 56,  114 => 49,  110 => 47,  104 => 44,  100 => 42,  98 => 41,  93 => 39,  86 => 35,  82 => 33,  79 => 32,  72 => 29,  56 => 22,  43 => 15,  36 => 11,  19 => 1,  235 => 95,  230 => 92,  220 => 87,  214 => 83,  206 => 80,  202 => 78,  200 => 77,  195 => 75,  190 => 73,  185 => 72,  179 => 70,  177 => 69,  171 => 66,  166 => 65,  162 => 64,  155 => 61,  153 => 60,  147 => 57,  141 => 54,  136 => 53,  130 => 51,  128 => 50,  121 => 53,  116 => 45,  112 => 44,  105 => 40,  94 => 32,  90 => 31,  83 => 26,  81 => 25,  77 => 31,  71 => 21,  65 => 24,  63 => 18,  59 => 17,  52 => 21,  46 => 10,  42 => 8,  39 => 7,  32 => 4,  29 => 7,);
    }
}
