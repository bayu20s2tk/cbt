<?php

/* layout-print-soal.html */
class __TwigTemplate_ada9477018d5c0f354bb631b7dcfd24d9ab27719fcb834d793919269e8a1d420 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'css' => array($this, 'block_css'),
            'content' => array($this, 'block_content'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<!DOCTYPE html>
<html>
<head>
    <title>";
        // line 4
        $this->displayBlock('title', $context, $blocks);
        echo "</title>
    ";
        // line 5
        $this->env->loadTemplate("layout-header.html")->display($context);
        // line 6
        echo "    <style type=\"text/css\">
        h3.title {
            margin-bottom: 0px;
            line-height: 30px;
        }
        hr.top {
            border: none;
            border-bottom: 2px solid #333;
            margin-bottom: 10px;
            margin-top: 10px;
        }
\t\t.opsi {
\t\t\tborder : none;
\t\t\tline-height : 0px;
\t\t}
    </style>
    ";
        // line 22
        $this->displayBlock('css', $context, $blocks);
        // line 23
        echo "</head>
<body>
    <div class=\"container\">
        <div class=\"row\">
            
        </div>
        <br>
        ";
        // line 30
        $this->displayBlock('content', $context, $blocks);
        // line 31
        echo "    </div>
</body>
</html>
";
    }

    // line 4
    public function block_title($context, array $blocks = array())
    {
        echo twig_escape_filter($this->env, (isset($context["site_name"]) ? $context["site_name"] : null), "html", null, true);
    }

    // line 22
    public function block_css($context, array $blocks = array())
    {
    }

    // line 30
    public function block_content($context, array $blocks = array())
    {
    }

    public function getTemplateName()
    {
        return "layout-print-soal.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  82 => 30,  77 => 22,  71 => 4,  64 => 31,  62 => 30,  53 => 23,  51 => 22,  33 => 6,  31 => 5,  27 => 4,  22 => 1,  150 => 60,  145 => 57,  135 => 52,  129 => 48,  121 => 45,  117 => 43,  115 => 42,  110 => 40,  104 => 37,  99 => 36,  95 => 35,  88 => 32,  86 => 31,  80 => 28,  72 => 23,  67 => 22,  63 => 21,  56 => 17,  49 => 13,  42 => 8,  39 => 7,  32 => 4,  29 => 3,);
    }
}
