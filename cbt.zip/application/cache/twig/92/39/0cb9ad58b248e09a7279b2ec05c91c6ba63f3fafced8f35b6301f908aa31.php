<?php

/* ujian-online.html */
class __TwigTemplate_92390cb9ad58b248e09a7279b2ec05c91c6ba63f3fafced8f35b6301f908aa31 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = $this->env->loadTemplate("layout-ujian.html");

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'css' => array($this, 'block_css'),
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout-ujian.html";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        // line 4
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["data"]) ? $context["data"] : null), "tugas"), "judul"), "html", null, true);
        echo " - ";
        $this->displayParentBlock("title", $context, $blocks);
        echo "
";
    }

    // line 7
    public function block_css($context, array $blocks = array())
    {
        // line 8
        echo "<style type=\"text/css\">
    .no-list {
        padding-left: 0px;
        list-style: outside none none;
        margin-top: 20px;
        margin-right: 12px;
    }
    .no-list li {
        width: 12.5%;
        font-size: 12px;
    }
    .no-list li {
        float: left;
        width: 25%;
        padding: 10px;
        font-size: 15px;
        line-height: 1.4;
        text-align: center;
        border: 1px solid #FFF;
        background-color: #e2e7ec;
    }
    .no-list li.success {
        background-color: green;
        color: white;
        font-weight: bold;
    }
    .no-list li.success > a {
        color: white;
    }
    .no-list li.ragu {
        background-color: #f89406;
        color: white;
        font-weight: bold;
    }
    .no-list li.ragu > a {
        color: white;
    }
    .nomor-navigasi ul.no-list {
        width: 130px;
        height: 700px;
        overflow: auto;
    }
    .nomor-navigasi.affix {
        margin-top: 5px;
    }
    .clock.affix {
        margin-top: -50px;
        margin-left: 60px;
    }
</style>
";
    }

    // line 60
    public function block_content($context, array $blocks = array())
    {
        // line 61
        echo "<div id=\"wrap\">
    <div class=\"container\">
        <div class=\"row-fluid\">
            <div class=\"span6\">
                <h1 class=\"title\">";
        // line 65
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["data"]) ? $context["data"] : null), "tugas"), "judul"), "html", null, true);
        echo "</h1>
\t\t\t\t<h5 class=\"title\">
\t\t\t\t<li> Zoom in/ out halaman jika ingin lebih jelas.</li>
\t\t\t\t<li> Fungsi kembali/back pada browser tidak disarankan, karena konsekuensinya ujian akan terhenti.</li>
\t\t\t\t</h5>
            </div>
            <div class=\"span6\">
                <ul class=\"unstyled inline pull-right user-info\">
                    <li><b>";
        // line 73
        echo twig_escape_filter($this->env, nama_panggilan(get_sess_data("user", "nama")), "html", null, true);
        echo "</b></li>
                    <!-- <li><img src=\"";
        // line 74
        echo twig_escape_filter($this->env, get_url_image_session(get_sess_data("user", "foto"), "medium", get_sess_data("user", "jenis_kelamin")), "html", null, true);
        echo "\" class=\"nav-avatar img-polaroid img-circle\" /></li>-->
                </ul>
            </div>
        </div>
        <hr class=\"hr-top\">
        <div class=\"wrap-content\">
            <div class=\"content\">
                <div class=\"row-fluid\">
                    ";
        // line 82
        if (($this->getAttribute($this->getAttribute((isset($context["data"]) ? $context["data"] : null), "tugas"), "type_id") != 1)) {
            // line 83
            echo "                    <div class=\"span8\">
                        <b>Informasi : </b><br>
                        ";
            // line 85
            echo $this->getAttribute($this->getAttribute((isset($context["data"]) ? $context["data"] : null), "tugas"), "info");
            echo "
                    </div>
                    <div class=\"span4\">
                        <div class=\"pull-right clock\" data-spy=\"affix\" data-offset-top=\"60\" data-offset-bottom=\"200\">
                            <div class=\"box-show-hide-countdown\">
                                ";
            // line 90
            $context["hide_countdown"] = sess_hide_countdown("get", $this->getAttribute($this->getAttribute((isset($context["data"]) ? $context["data"] : null), "tugas"), "id"));
            // line 91
            echo "                                ";
            if (((isset($context["hide_countdown"]) ? $context["hide_countdown"] : null) == 1)) {
                // line 92
                echo "                                    <a href=\"javascript:void(0)\" onclick=\"show_countdown()\" class=\"text-muted\"><i class=\"icon icon-eye-open\"></i> TAMPILKAN SISA WAKTU</a>
                                ";
            } else {
                // line 94
                echo "                                    <a href=\"javascript:void(0)\" onclick=\"hide_countdown()\" class=\"text-muted\"><i class=\"icon icon-eye-close\"></i> SEMBUNYIKAN SISA WAKTU</a>
                                ";
            }
            // line 96
            echo "                            </div>
                            <div class=\"iosl-theme-wrapper countdown\" ";
            // line 97
            echo ((((isset($context["hide_countdown"]) ? $context["hide_countdown"] : null) == 1)) ? ("style=\"display:none;\"") : (""));
            echo ">
                                <div class=\"iosl-theme\">
                                    <ul>
                                        <li><p><span><em><b class=\"hours\">00</b><i class=\"hoursSlider\"><u>00</u><u>00</u></i></em></span></p></li>
                                        <li><p><span><em><b class=\"minutes\">00</b><i class=\"minutesSlider\"><u>00</u><u>00</u></i></em></span></p></li>
                                        <li><p><span><em><b class=\"seconds\">00</b><i class=\"secondsSlider\"><u>00</u><u>00</u></i></em></span></p></li>
                                    </ul>
                                    <div class=\"jC-clear\"></div>
                                    <p class=\"jCtext\">
                                        <span><em class=\"textSeconds\">SECONDS</em></span>
                                        <span><em class=\"textMinutes\">MINUTES</em></span>
                                        <span><em class=\"textHours\">HOURS</em></span>
                                    </p>
                                    <div class=\"jC-clear\"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                    ";
        } else {
            // line 116
            echo "                    <div class=\"span6\">
                        <p><b>Upload file tugas anda : </b></p>
                        <div class=\"well well-sm\">
                            ";
            // line 119
            echo form_open_multipart(((("tugas/submit_upload/" . $this->getAttribute($this->getAttribute((isset($context["data"]) ? $context["data"] : null), "tugas"), "id")) . "/") . $this->getAttribute((isset($context["data"]) ? $context["data"] : null), "unix_id")));
            echo "
                            <input type=\"file\" name=\"userfile\">
                            <hr class=\"hr1\">
                            <small>Jenis file dokumen yang diizinkan : doc,docx,zip,rar,txt,xls,xlsx,pdf,PDF,tar,gz,jpg,jpeg,JPG,JPEG,png,PNG,ppt,pptx</small>
                            <small>Jenis file audio yang diizinkan : MP4,m4a,MP3,mp3</small>
                            <small>Ukuran maksimal : 5 MB</small>
                            <div class=\"row-fluid\">
                                <div class=\"span3\">
                                    <button type=\"submit\" class=\"btn btn-primary\">Upload</button>
                                </div>
                                <div class=\"span9\">
                                    ";
            // line 130
            echo get_flashdata("upload");
            echo "
                                </div>
                            </div>
                            ";
            // line 133
            echo form_close();
            echo "
                        </div>
\t\t\t\t\t\t<div class=\"well well-sm well-box\">
\t\t\t\t\t\t<ul > 
\t\t\t\t\t\t\t<li> Menggunakan app CAM SCANNER untuk mengambil gambar dengan ukuran yang kecil.
\t\t\t\t\t\t\t\t<ol>
\t\t\t\t\t\t\t\t\t<li>Android :<a href=\"https://play.google.com/store/apps/details?id=com.intsig.camscanner&hl=en\"> Unduh dan install aplikasi </a></li>
\t\t\t\t\t\t\t\t\t<li>Iphone :<a href=\"https://apps.apple.com/us/app/camscanner-pdf-scanner-app/id388627783\"> Unduh dan install aplikasi </a></li>
\t\t\t\t\t\t\t\t</ol>
\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t<li> Menggunakan aplikasi WINRAR
\t\t\t\t\t\t\t\t<ol>
\t\t\t\t\t\t\t\t\t<li>Unduh dan install aplikasi winrar pada perangkat mobile atau PC/laptop</li>
\t\t\t\t\t\t\t\t\t<li>Android :<a href=\"https://play.google.com/store/apps/details?id=com.rarlab.rar&hl=en\"> Unduh dan install aplikasi </a></li>
\t\t\t\t\t\t\t\t\t<li>Iphone :<a href=\"https://apps.apple.com/us/app/izip-zip-unzip-unrar-tool/id413971331\"> Unduh dan install aplikasi </a></li>
\t\t\t\t\t\t\t<li>Kemudian gabungkan file yang akan kamu upload</li>
\t\t\t\t\t\t\t<li>Jika berhasil file akan berekstensi .rar</li>
\t\t\t\t\t\t\t\t</ol>
\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t</ul>
\t\t\t\t\t\t<ul > 
\t\t\t\t\t\t\t<li> Menggunakan mobile app Image to PDF Converter 2019
\t\t\t\t\t\t\t\t<ol>
\t\t\t\t\t\t\t\t\t<li>Unduh dan install aplikasi tsb pada perangkat mobile</li>
\t\t\t\t\t\t\t<li>Select files</li>
\t\t\t\t\t\t\t<li>Jika berhasil file akan berekstensi .pdf</li>
\t\t\t\t\t\t\t\t</ol>
\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t</ul>
                            
                            <div class=\"row-fluid\">
                                <div class=\"span3\">
                                   
                                </div>
                                <div class=\"span9\">
                                    
                                </div>
                            </div>
                            
                        </div>
                    </div>
\t\t\t\t\t\t
\t\t\t\t\t
                    <div class=\"span6\">
                        <b>Informasi Tugas : </b><br>
                        ";
            // line 178
            echo $this->getAttribute($this->getAttribute((isset($context["data"]) ? $context["data"] : null), "tugas"), "info");
            echo "
                    </div>
                    ";
        }
        // line 181
        echo "                </div>

                ";
        // line 183
        if (($this->getAttribute($this->getAttribute((isset($context["data"]) ? $context["data"] : null), "tugas"), "type_id") == 3)) {
            // line 184
            echo "                    <div class=\"row-fluid\">
                        <div class=\"span10\">
                            <table class=\"table datatable\">
                                <thead>
                                    <tr>
                                        <th style=\"width:40px;\">No</th>
                                        <th>Pertanyaan dan Pilihan</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    ";
            // line 194
            $context['_parent'] = (array) $context;
            $context['_seq'] = twig_ensure_traversable($this->getAttribute((isset($context["data"]) ? $context["data"] : null), "pertanyaan"));
            foreach ($context['_seq'] as $context["no"] => $context["p"]) {
                // line 195
                echo "                                    <tr id=\"pertanyaan-";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["p"]) ? $context["p"] : null), "id"), "html", null, true);
                echo "\">
                                        <td><b>";
                // line 196
                echo twig_escape_filter($this->env, (isset($context["no"]) ? $context["no"] : null), "html", null, true);
                echo ".</b></td>
                                        <td>
                                            <div class=\"pertanyaan\">
                                                ";
                // line 199
                echo $this->getAttribute((isset($context["p"]) ? $context["p"] : null), "pertanyaan");
                echo "
                                            </div>

                                            <div id=\"pilihan-";
                // line 202
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["p"]) ? $context["p"] : null), "id"), "html", null, true);
                echo "\">
                                                <table class=\"table table-condensed table-striped\">
                                                    <tbody>
                                                        ";
                // line 205
                $context['_parent'] = (array) $context;
                $context['_seq'] = twig_ensure_traversable($this->getAttribute((isset($context["p"]) ? $context["p"] : null), "pilihan"));
                $context['loop'] = array(
                  'parent' => $context['_parent'],
                  'index0' => 0,
                  'index'  => 1,
                  'first'  => true,
                );
                foreach ($context['_seq'] as $context["_key"] => $context["pil"]) {
                    if ((!twig_test_empty($this->getAttribute((isset($context["pil"]) ? $context["pil"] : null), "konten")))) {
                        // line 206
                        echo "                                                        <tr>
                                                            <td style=\"width:30px;\"><label class=\"label-radio\"><input ";
                        // line 207
                        echo ((is_pilih($this->getAttribute((isset($context["data"]) ? $context["data"] : null), "jawaban"), $this->getAttribute((isset($context["p"]) ? $context["p"] : null), "id"), $this->getAttribute((isset($context["pil"]) ? $context["pil"] : null), "id"))) ? ("checked") : (""));
                        echo " type=\"radio\" name=\"pilihan-";
                        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["p"]) ? $context["p"] : null), "id"), "html", null, true);
                        echo "\" value=\"";
                        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["pil"]) ? $context["pil"] : null), "urutan"), "html", null, true);
                        echo "\" onclick=\"update_ganda_custom(";
                        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["data"]) ? $context["data"] : null), "tugas"), "id"), "html", null, true);
                        echo ", ";
                        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["p"]) ? $context["p"] : null), "id"), "html", null, true);
                        echo ", ";
                        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["pil"]) ? $context["pil"] : null), "id"), "html", null, true);
                        echo ")\" class=\"radio\"> ";
                        echo twig_escape_filter($this->env, get_abjad($this->getAttribute((isset($context["loop"]) ? $context["loop"] : null), "index")), "html", null, true);
                        echo "</label></td>
                                                            <td>
                                                                ";
                        // line 209
                        echo $this->getAttribute((isset($context["pil"]) ? $context["pil"] : null), "konten");
                        echo "
                                                            </td>
                                                        </tr>
                                                        ";
                        ++$context['loop']['index0'];
                        ++$context['loop']['index'];
                        $context['loop']['first'] = false;
                    }
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['_iterated'], $context['_key'], $context['pil'], $context['_parent'], $context['loop']);
                $context = array_intersect_key($context, $_parent) + $_parent;
                // line 213
                echo "
                                                        ";
                // line 214
                if ((!twig_test_empty($this->getAttribute($this->getAttribute((isset($context["data"]) ? $context["data"] : null), "jawaban"), $this->getAttribute((isset($context["p"]) ? $context["p"] : null), "id"), array(), "array")))) {
                    // line 215
                    echo "                                                        <tr id=\"ragu-";
                    echo twig_escape_filter($this->env, $this->getAttribute((isset($context["p"]) ? $context["p"] : null), "id"), "html", null, true);
                    echo "\" class=\"warning\">
                                                            <td colspan=\"2\">
                                                                <label class=\"checkbox\">
                                                                    <input type=\"checkbox\" name=\"ragu\" onclick=\"update_ragu(this.checked, ";
                    // line 218
                    echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["data"]) ? $context["data"] : null), "tugas"), "id"), "html", null, true);
                    echo ", ";
                    echo twig_escape_filter($this->env, $this->getAttribute((isset($context["p"]) ? $context["p"] : null), "id"), "html", null, true);
                    echo ")\" ";
                    echo ((((!twig_test_empty($this->getAttribute((isset($context["data"]) ? $context["data"] : null), "ragu"))) && in_array($this->getAttribute((isset($context["p"]) ? $context["p"] : null), "id"), $this->getAttribute((isset($context["data"]) ? $context["data"] : null), "ragu")))) ? ("checked") : (""));
                    echo "> <b>Masih ragu-ragu</b>
                                                                </label>
                                                            </td>
                                                        </tr>
                                                        ";
                }
                // line 223
                echo "                                                    </tbody>
                                                </table>
                                            </div>

                                        </td>
                                    </tr>

                                    ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['no'], $context['p'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 231
            echo "                                </tbody>
                            </table>

                            ";
            // line 234
            echo (isset($context["pagination"]) ? $context["pagination"] : null);
            echo "

                            ";
            // line 236
            if (((isset($context["tampil_btn_submit"]) ? $context["tampil_btn_submit"] : null) == 1)) {
                // line 237
                echo "                            <div class=\"well well-sm\">
                                <p class=\"p-info\">Periksa kembali jawaban anda sebelum mengahiri pengerjaan tugas ini.</p>
                                <button type=\"button\" class=\"btn btn-large btn-primary\" data-toggle=\"modal\" data-target=\"#selesai-mengerjakan\">
                                    Selesai Mengerjakan
                                </button>
                            </div>
                            ";
            }
            // line 244
            echo "
                            <div class=\"modal fade\" id=\"selesai-mengerjakan\" tabindex=\"-1\" role=\"dialog\">
                                <div class=\"modal-dialog\" role=\"document\">
                                    <div class=\"modal-content\">
                                        <div class=\"modal-body\">
                                            Anda yakin ingin mengahiri pengerjaan tugas ini?
                                        </div>
                                        <div class=\"modal-footer\">
                                            <button type=\"button\" class=\"btn btn-default\" data-dismiss=\"modal\">Nanti dulu</button>
                                            <a class=\"btn btn-primary\" href=\"";
            // line 253
            echo twig_escape_filter($this->env, site_url(((("tugas/finish/" . $this->getAttribute($this->getAttribute((isset($context["data"]) ? $context["data"] : null), "tugas"), "id")) . "/") . $this->getAttribute((isset($context["data"]) ? $context["data"] : null), "unix_id"))), "html", null, true);
            echo "\" id=\"btn-submit\">Ya, saya sudah selesai</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class=\"span2\">
                            <div class=\"nomor-navigasi\">
                                <ul class=\"no-list\">
                                    ";
            // line 262
            $context['_parent'] = (array) $context;
            $context['_seq'] = twig_ensure_traversable($this->getAttribute((isset($context["data"]) ? $context["data"] : null), "pertanyaan_id"));
            foreach ($context['_seq'] as $context["no"] => $context["p_id"]) {
                // line 263
                echo "                                        ";
                $context["no_class"] = "";
                // line 264
                echo "                                        ";
                if (((!twig_test_empty($this->getAttribute((isset($context["data"]) ? $context["data"] : null), "ragu"))) && in_array((isset($context["p_id"]) ? $context["p_id"] : null), $this->getAttribute((isset($context["data"]) ? $context["data"] : null), "ragu")))) {
                    // line 265
                    echo "                                            ";
                    $context["no_class"] = "ragu";
                    // line 266
                    echo "                                        ";
                } elseif ((!twig_test_empty($this->getAttribute($this->getAttribute((isset($context["data"]) ? $context["data"] : null), "jawaban"), (isset($context["p_id"]) ? $context["p_id"] : null), array(), "array")))) {
                    // line 267
                    echo "                                            ";
                    $context["no_class"] = "success";
                    // line 268
                    echo "                                        ";
                }
                // line 269
                echo "                                        <li id=\"no-pertanyaan-";
                echo twig_escape_filter($this->env, (isset($context["p_id"]) ? $context["p_id"] : null), "html", null, true);
                echo "\" class=\"";
                echo twig_escape_filter($this->env, (isset($context["no_class"]) ? $context["no_class"] : null), "html", null, true);
                echo "\"><a href=\"";
                echo twig_escape_filter($this->env, site_url(((((("plugins/custom_tugas/kerjakan/" . $this->getAttribute($this->getAttribute((isset($context["data"]) ? $context["data"] : null), "tugas"), "id")) . "/") . $this->getAttribute((isset($context["halaman"]) ? $context["halaman"] : null), (isset($context["p_id"]) ? $context["p_id"] : null), array(), "array")) . "#pertanyaan-") . (isset($context["p_id"]) ? $context["p_id"] : null))), "html", null, true);
                echo "\">";
                echo twig_escape_filter($this->env, (isset($context["no"]) ? $context["no"] : null), "html", null, true);
                echo "</a></li>
                                    ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['no'], $context['p_id'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 271
            echo "                                </ul>
                            </div>
                        </div>
                    </div>

                ";
        }
        // line 277
        echo "

                ";
        // line 279
        if (($this->getAttribute($this->getAttribute((isset($context["data"]) ? $context["data"] : null), "tugas"), "type_id") == 2)) {
            // line 280
            echo "                    ";
            echo form_open(((("plugins/custom_tugas/submit_essay/" . $this->getAttribute($this->getAttribute((isset($context["data"]) ? $context["data"] : null), "tugas"), "id")) . "/") . $this->getAttribute((isset($context["data"]) ? $context["data"] : null), "unix_id")), array("id" => "form-essay"));
            echo "
                    <input type=\"hidden\" id=\"str_id\" value=\"";
            // line 281
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["data"]) ? $context["data"] : null), "str_id"), "html", null, true);
            echo "\">
                    <table class=\"table datatable\">
                        <thead>
                            <tr>
                                <th width=\"5%\">No</th>
                                <th>Pertanyaan</th>
                            </tr>
                        </thead>
                        <tbody>
                            ";
            // line 290
            $context['_parent'] = (array) $context;
            $context['_seq'] = twig_ensure_traversable($this->getAttribute((isset($context["data"]) ? $context["data"] : null), "pertanyaan"));
            foreach ($context['_seq'] as $context["no"] => $context["p"]) {
                // line 291
                echo "                            <tr id=\"pertanyaan-";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["p"]) ? $context["p"] : null), "id"), "html", null, true);
                echo "\">
                                <td><b>";
                // line 292
                echo twig_escape_filter($this->env, (isset($context["no"]) ? $context["no"] : null), "html", null, true);
                echo ".</b></td>
                                <td>
                                    <div class=\"pertanyaan\">
                                        ";
                // line 295
                echo $this->getAttribute((isset($context["p"]) ? $context["p"] : null), "pertanyaan");
                echo "
                                    </div>

                                    <textarea name=\"jawaban[";
                // line 298
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["p"]) ? $context["p"] : null), "id"), "html", null, true);
                echo "]\" id=\"jawaban-";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["p"]) ? $context["p"] : null), "id"), "html", null, true);
                echo "\" class=\"texteditor\">";
                echo get_jawaban($this->getAttribute((isset($context["data"]) ? $context["data"] : null), "jawaban"), $this->getAttribute((isset($context["p"]) ? $context["p"] : null), "id"));
                echo "</textarea>

                                </td>
                            </tr>

                            ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['no'], $context['p'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 304
            echo "                        </tbody>
                    </table>

                    ";
            // line 307
            echo (isset($context["pagination"]) ? $context["pagination"] : null);
            echo "

                    <div id=\"info-ajax-href\"></div>

                    ";
            // line 311
            if (((isset($context["tampil_btn_submit"]) ? $context["tampil_btn_submit"] : null) == 1)) {
                // line 312
                echo "                    <div class=\"well well-sm\">
                        <p class=\"p-info\">Periksa kembali jawaban anda sebelum mengahiri pengerjaan tugas ini.</p>
                        <button type=\"button\" class=\"btn btn-large btn-primary\" data-toggle=\"modal\" data-target=\"#selesai-mengerjakan\">
                            Selesai Mengerjakan
                        </button>
                    </div>
                    ";
            }
            // line 319
            echo "
                    ";
            // line 320
            echo form_close();
            echo "

                    <div class=\"modal fade\" id=\"selesai-mengerjakan\" tabindex=\"-1\" role=\"dialog\">
                        <div class=\"modal-dialog\" role=\"document\">
                            <div class=\"modal-content\">
                                <div class=\"modal-body\">
                                    Anda yakin ingin mengahiri pengerjaan tugas ini?
                                </div>
                                <div class=\"modal-footer\">
                                    <button type=\"button\" class=\"btn btn-default\" data-dismiss=\"modal\">Nanti dulu</button>
                                    <button type=\"button\" class=\"btn btn-primary\" id=\"btn-submit\">Ya, saya sudah selesai</button>
                                </div>
                            </div>
                        </div>
                    </div>

                ";
        }
        // line 337
        echo "
            </div>
        </div>
    </div>
</div>
";
        // line 342
        if (($this->getAttribute($this->getAttribute((isset($context["data"]) ? $context["data"] : null), "tugas"), "type_id") != 1)) {
            // line 343
            echo "<input type=\"hidden\" id=\"process-submit\" value=\"0\">
<input type=\"hidden\" id=\"tugas_id\" value=\"";
            // line 344
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["data"]) ? $context["data"] : null), "tugas"), "id"), "html", null, true);
            echo "\">
<input type=\"hidden\" id=\"type_id\" value=\"";
            // line 345
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["data"]) ? $context["data"] : null), "tugas"), "type_id"), "html", null, true);
            echo "\">
<input type=\"hidden\" id=\"sisa_menit\" value=\"";
            // line 346
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["data"]) ? $context["data"] : null), "sisa_menit"), "html", null, true);
            echo "\">
<input type=\"hidden\" id=\"finish_url\" value=\"";
            // line 347
            echo twig_escape_filter($this->env, site_url(((("plugins/custom_tugas/finish/" . $this->getAttribute($this->getAttribute((isset($context["data"]) ? $context["data"] : null), "tugas"), "id")) . "/") . $this->getAttribute((isset($context["data"]) ? $context["data"] : null), "unix_id"))), "html", null, true);
            echo "\">
<input type=\"hidden\" id=\"siswa_id\" value=\"";
            // line 348
            echo twig_escape_filter($this->env, get_sess_data("user", "id"), "html", null, true);
            echo "\">
";
        }
    }

    public function getTemplateName()
    {
        return "ujian-online.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  614 => 348,  610 => 347,  606 => 346,  602 => 345,  598 => 344,  595 => 343,  593 => 342,  586 => 337,  566 => 320,  563 => 319,  554 => 312,  552 => 311,  545 => 307,  540 => 304,  524 => 298,  518 => 295,  512 => 292,  507 => 291,  503 => 290,  491 => 281,  486 => 280,  484 => 279,  480 => 277,  472 => 271,  457 => 269,  454 => 268,  451 => 267,  448 => 266,  445 => 265,  442 => 264,  439 => 263,  435 => 262,  423 => 253,  412 => 244,  403 => 237,  401 => 236,  396 => 234,  391 => 231,  378 => 223,  366 => 218,  359 => 215,  357 => 214,  354 => 213,  340 => 209,  323 => 207,  320 => 206,  309 => 205,  303 => 202,  297 => 199,  291 => 196,  286 => 195,  282 => 194,  270 => 184,  268 => 183,  264 => 181,  258 => 178,  210 => 133,  204 => 130,  190 => 119,  185 => 116,  163 => 97,  160 => 96,  156 => 94,  152 => 92,  149 => 91,  147 => 90,  139 => 85,  135 => 83,  133 => 82,  122 => 74,  118 => 73,  107 => 65,  101 => 61,  98 => 60,  44 => 8,  41 => 7,  33 => 4,  30 => 3,);
    }
}
